#include "b.c"




//using namespace std;

int main(int argc, char ** argv)
{
	//initialpage("chat",90,0);
	//("movie",100,0);

	if (argc > 1) {
		char * input_file = argv[1];
		//fp = fopen(input_file, "r");
		run(input_file);
	}
	/*initialpage("chat",90,0);
	cout<< relation1["chat"]<<endl;

	insert1("chat", 40, "egegwgweg");*/
	/*
	initialpage("test",250,0);
	//root=initialpage("chat");
	//char *ss;
	//char *ss2="fdsafas";

	page*b=relation["chat"];
	insert("chat",40,"fdsafz");
	page*c=relation["test"];

	insert("chat",25,"fds");
	insert("chat",60,"aaaasaghjgjhgjfa");
	for(int i=0;i<11;i++)
	{
		insert("chat",40,"aaa");
		insert("test",60,"bbbbb");
	}
	delet("test",4,1);
	insert("test",60,"bbbbbbb");
	delet("test",4,1);
	for(int i=0;i<512;i++)
	{
	//	printf("%c",b->data[i]);
	}

	p("test",4);
	printf("%d\n",co("test"));*/
//	system("pause");
	return 0;
}
