#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <map>

using namespace std;
typedef struct slotdir;
typedef struct data;
typedef struct slot;
typedef struct page;
page *root;
int countid=0;

struct cmp_str
{
   bool operator()(char const *a, char const *b)
   {
      return strcmp(a, b) < 0;
   }
};

map<char*,page*,cmp_str > relation1;
map<char*,int, cmp_str> relationsize;
map<char*,int, cmp_str> relationcountid;
typedef struct forbtree
{
	int pageid;
	int slotnum;
};
typedef struct page
{
	int pageid;					
	int size;                   //512
	char data[512];
	//data1 a;
	slotdir *slotd;				//to slotdir
	page *nextpage;
};
typedef struct slot     //each slot value
{
	bool flag;
	int key;				//keep record integer index
	//char* str;				//keep record string index 
	int pageid;				//keep pageid
	int slotid;				//keep slotidnumber
	char *record;			//keep record 
	short start;			//start byte	
	short length;			//lenght byte
	slot *next;				//point to next slot
};
typedef struct slotdir //initiall directory slot
{
	data *da;
	short freespace;    
	short numslotspace;    //number of slot base
	slot *value;
	
}slot1;

slot *initialslot(int ke,short star,short lengt,int paid)
{
	slot*sl=(slot *)malloc(sizeof(slot));
	sl->next=NULL;
	sl->flag=true;
	sl->key=ke;
	sl->start=star;
	sl->length=lengt;
	sl->pageid=paid;
	
	return sl;
}
page* initialpage(char *s,int len,int flag1) //s=relation1 len=attribute  flag is to test the initial or not
{
	
	if(relation1.find(s)==relation1.end()&&flag1==0)  //first create relation1.
	{
		relationcountid[s]=0;
		page *a=(page *)malloc(sizeof(page));
		slotdir *dir=(slotdir *)malloc(sizeof(slotdir));
		a->slotd=dir;
		a->slotd->freespace=0;
		a->slotd->numslotspace=0;
		a->pageid=relationcountid[s];
		a->size=512;
		a->slotd->value=NULL;
		relationcountid[s]+=1;
		relation1[s]=a;				//keep the root to the relation1's page
		relationsize[s]=len;        //keep the size of attribute
			for(int i=0;i<512;i++)
			{
				a->data[i]='0';
			}
			a->nextpage=NULL;
		return a;
	}
	else if(flag1==0)
		{
			return relation1[s];
		}
	if(flag1==1)
	{
		page *a=(page *)malloc(sizeof(page));
		slotdir *dir=(slotdir *)malloc(sizeof(slotdir));
		a->slotd=dir;
		a->slotd->freespace=0;
		a->slotd->numslotspace=0;
		a->pageid=relationcountid[s];
		a->size=512;
		a->slotd->value=NULL;
		relationcountid[s]+=1;
		a->nextpage=NULL;
		return a;
	}

}
forbtree* insert1(char *re,int index,char *s)
{
	int size=strlen(s);
	page *root=relation1[re];

	slot *point;
	forbtree *tree=(forbtree*)malloc(sizeof(forbtree));
	slot *sl;
	while(1)
	{
		//cout << relation1[re] << "*******" << endl;
		 point=root->slotd->value;//cout <<"fuck\n";
	if(root->slotd->freespace+relationsize[re]<512-(root->slotd->numslotspace)*sizeof(8)) //changed 512
	{
		for(int i=0;i<size;i++)   //不確定會不會overflow
		{
			root->data[i+root->slotd->freespace]=*(s+i);
		}
		
		sl=initialslot(index,root->slotd->freespace,size,root->pageid);
		if(root->slotd->numslotspace!=0)  //otherwise
		{
			while(point->next!=NULL)
			{
			point=point->next;
			}
			point->next=sl;
			sl->slotid=point->slotid+1;
		//	sl->next=NULL;
		}
		else                           //first slot
		{
			root->slotd->value=sl;
			sl->slotid=0;
		//	sl->next=NULL;
		}
	
		root->slotd->numslotspace++;
		root->slotd->freespace+=relationsize[re];
		break;
	}
	else								//check the fractionspace or create new page;
	{
		slot *ite=root->slotd->value->next;
		while(ite!=NULL) //check all the slot space to put the record     untest
		{
			if(ite->flag==0)
			{
				if(relationsize[re]>=size)     //does it have better
				{
					for(int i=0;i<size;i++)
					{
						root->data[i+ite->start]=*(s+i);
					}
					ite->length=size;
					ite->flag=1;
					root->slotd->numslotspace++;
					tree->pageid=root->pageid;
					tree->slotnum=ite->slotid;
				return tree;
				}
			}
			ite=ite->next;
		}
		if(root->nextpage==NULL)
		{
		root->nextpage=initialpage(re,relationsize[re],1);
		}
		root=root->nextpage;
		
		}
		
		
	}
	tree->pageid=root->pageid;
	tree->slotnum=sl->slotid;
	printf(" insert (page, slot) = (%d, %d) ", root->pageid, sl->slotid);
	return tree;
}
int delet(char*re,int pageidb,int slotnumb)
{

	root=relation1[re];
	slot *temp; //just a point to search
	while(pageidb!=root->pageid)
	{
		if(root->nextpage!=NULL)
		{
			root=root->nextpage;
		}
		else
		{
			printf("delete key is wrong\n");
			return 0;
		}

	}
	temp=root->slotd->value;
	while(temp->slotid!=slotnumb)
	{
		if(temp->next!=NULL)
		{
		temp=temp->next;
		}
		else
		{
		break;
		}
	}
	if(temp->slotid==slotnumb)   //可能要減掉一個slotnum;
	{
		temp->flag=0;
		root->slotd->numslotspace--;
	}
	else
	{
		printf("slot is not exist\n");
	}
	
	printf("");
return 0;
}
int q1(char *re,int pageidb,int slotnum) //single key search
{
	root=relation1[re];
	slot *temp;
	while(root->pageid!=pageidb)
	{
		if(root->nextpage!=NULL)
		{
		root=root->nextpage;
		}
		else
		{
		printf("search single key fail\n");
		break;
		}
	}
	temp=root->slotd->value;
	while(temp->slotid!=slotnum)
	{
		if(temp->next!=NULL)
		{
			temp=temp->next;
		}
		else
		{
			printf("slotnum is wrong\n");
			return 0;
		}
	
	}
	int a=temp->start;
	int b=temp->length;
	/*for(int i=a;i<a+b;i++)
	{
		printf("%c",root->data[i]);
	}*/
	return 0;
}
int p(char *re,int pageidb)
{
	root=relation1[re];
	slot *temp;
	while(root->pageid!=pageidb)      //lose page id 1;
	{
		if(root->nextpage!=NULL)
		{
		root=root->nextpage;
		}
		else
		{
		printf("page is not exist\n");
		return 0;
		}
	}
	temp=root->slotd->value;
	int a,b;
	while(temp!=NULL)                   //not sure will it overflow?
	{
		if(temp->flag==1)
		{
			a=temp->start;
			b=temp->length;
			for(int i=a;i<a+b;i++)
			{
				printf("%c",root->data[i]);
			}
			printf("\n");
			
			
		}
		temp=temp->next;
	}
	return 0;
}
int co(char *s)
{
	int i=relationcountid[s];
	return i+1;
}

/*
int main(int argc, char ** argv)
{
	//initialpage("chat",90,0);
	//("movie",100,0);

	if (argc > 1) {
		char * input_file = argv[1];
		//fp = fopen(input_file, "r");
		run(input_file);
	}
    

	
	initialpage("test",250,0);
	//root=initialpage("chat");
	//char *ss;
	//char *ss2="fdsafas";

	page*b=relation1["chat"];
	insert1("chat",40,"fdsafz");
	page*c=relation1["test"];

	insert1("chat",25,"fds");
	insert1("chat",60,"aaaasaghjgjhgjfa");
	for(int i=0;i<11;i++)
	{
		insert1("chat",40,"aaa");
		insert1("test",60,"bbbbb");
	}
	delet("test",4,1);
	insert1("test",60,"bbbbbbb");
	delet("test",4,1);
	for(int i=0;i<512;i++)
	{
	//	printf("%c",b->data[i]);
	}

	p("test",4);
	printf("%d\n",co("test"));
//	system("pause");
	return 0;
}*/
